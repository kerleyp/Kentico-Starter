# 3-tier content gating: Public / Requires Login / Members Only

Adds an `AccessLevel` field alongside the existing `MembersOnly` checkbox on
`AUA.MemberGatingFields`, with 3 levels, ordered least → most restrictive:

- **Public** — anyone.
- **Requires Login** — visitor must be signed in via Google/Facebook (see `OAUTH_SETUP.md`),
  but doesn't need to be a confirmed AUA member.
- **Members Only** — visitor must be a confirmed AUA member. This is a strict superset of
  Requires Login, not a separate check — any confirmed member automatically satisfies a
  Requires Login page too, since being a member means being signed in.

**Correction from earlier:** I'd originally assumed no real pages had `MembersOnly` checked
yet and planned to just delete that field outright. You caught that some real pages already
have it checked — deleting the field would have silently un-gated that content. Fixed below:
`AccessLevel` is now added **alongside** `MembersOnly` (not a replacement), and
`migrate_access_level.sql` backfills it from whatever's already checked, so nothing currently
gated becomes public by accident. `MembersOnly` itself is left in place, unused by any
template — see step 5 for optional cleanup once you're confident the migration is correct.

---

## 1. Admin UI — add the new field (don't touch MembersOnly yet)

**Content Types → List of reusable field schemas → `AUA.MemberGatingFields` → Fields tab.**

Add a new field — do **not** delete `MembersOnly`:

- **Field name (codename):** `AccessLevel`
- **Data type:** Text
- **Form component:** Dropdown selector
- **Values** (configure these 3 exactly — the `Value` side must match what
  `ContentAccessLevelHelper.cs` and `migrate_access_level.sql` check for, case-sensitive):

  | Value | Caption |
  |---|---|
  | `Public` | Public |
  | `RequiresLogin` | Requires Login |
  | `MembersOnly` | Members Only |

- **Default value:** leave blank (the migration script below fills every existing page; new
  pages created after this point should have an editor deliberately choose a level — a
  Public-by-default dropdown makes it too easy to forget to actually gate something that should
  be gated).

Save. **Restart `dotnet run`** (stop and re-run, not just re-set an env var) before the next
step — same class-structure caching gotcha as every other content-type change in this project.

---

## 2. Backfill existing data — `migrate_access_level.sql`

Run this against your database (`sqlcmd` or SSMS, your choice) **before** relying on
`AccessLevel` in the live templates:

```powershell
sqlcmd -S <your-server> -d <your-db> -E -i migrate_access_level.sql
```

It sets `AccessLevel = 'MembersOnly'` on every page that currently has `MembersOnly` checked,
and `AccessLevel = 'Public'` on everything else, across all 3 content types. Safe to re-run —
only touches rows where `AccessLevel` is still blank. Ends with a verification query that
should return **zero** mismatches; if it doesn't, stop and figure out why before moving on
(don't proceed to codegen/templates with unverified data).

---

## 3. Regenerate code

```powershell
dotnet build
dotnet run --no-build -- --kxp-codegen --type "ReusableFieldSchemas" --namespace "AUA" --include "AUA.MemberGatingFields;AUA.RelatedTopicsFields;AUA.HeroImageFields"
dotnet run --no-build -- --kxp-codegen --type "PageContentTypes" --include "AUA.StandardContentPage"
dotnet run --no-build -- --kxp-codegen --type "PageContentTypes" --include "AUA.LongFormDocumentPage"
dotnet run --no-build -- --kxp-codegen --type "PageContentTypes" --include "AUA.ClinicalGuidanceDocument"
dotnet build
```

This generates `AccessLevel` alongside the still-present `MembersOnly` property — that's
expected and harmless, nothing in the templates references `MembersOnly` anymore (same
semicolon-not-comma `--include` rule as every other codegen run in this project — see
`FRESH_INSTALL.md` step 5 if any of this is unfamiliar).

---

## 4. New/changed code files

| File | Action |
|---|---|
| `Helpers/ContentAccessLevelHelper.cs` | New — the `ContentAccessLevel` enum + the parse/check logic |
| `PageTemplates/AUA/StandardContentPageDefault.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/LongFormDocumentPageDefault.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/ClinicalGuidanceDocumentAtomicPilot.cshtml` | Replace with the updated version |
| `migrate_access_level.sql` | Run once, per step 2 above |

All 3 templates now do this instead of the old `bool isMembersOnly = currentPage.MembersOnly;`:

```csharp
var accessLevel = ContentAccessLevelHelper.Parse(currentPage.AccessLevel);
bool visitorMeetsAccessLevel = ContentAccessLevelHelper.VisitorMeetsAccessLevel(accessLevel, Context);
```

and gate on `!visitorMeetsAccessLevel` instead of `isMembersOnly && !isAuaMember`, with the
gate message text branching on `accessLevel == ContentAccessLevel.MembersOnly` to say "for AUA
members only" vs. the more generic "please sign in."

---

## 5. Optional cleanup — delete the old `MembersOnly` field

Not required — `MembersOnly` sitting unused in the schema doesn't break anything. Do this later
once you've spot-checked real pages against the migration and you're confident nothing needs
it:

1. Admin UI → same Fields tab → delete `MembersOnly`.
2. Restart the app.
3. Re-run the same 3-command codegen sequence from step 3 (it'll just stop generating the now
   -deleted property).
4. `dotnet build`.

---

## 6. Verify

- [ ] `migrate_access_level.sql`'s verification query returns 0 for all 3 tables.
- [ ] Spot-check a couple of pages you know had `MembersOnly` checked before this change — they
      should now show `AccessLevel = MembersOnly` in the admin, and still gate correctly on the
      live site.
- [ ] `dotnet build` succeeds.
- [ ] A page with **AccessLevel = Public** is visible to everyone, signed in or not.
- [ ] A page with **AccessLevel = Requires Login**: signed-out visitor sees the gate + sign-in
      buttons; any signed-in visitor (member or not) sees the full content.
- [ ] A page with **AccessLevel = Members Only**: signed-out visitor sees the gate + sign-in
      buttons; signed-in-but-not-a-member visitor sees "signed in as X, but no active
      membership on file"; a confirmed member sees the full content.
- [ ] A confirmed member can also see Requires Login content (membership implies login).
