# Real "Sign in with Google / Facebook" — setup

Replaces the simulated-login footer toggle with real OAuth sign-in. The flow: visitor clicks
"Sign in with Google," Google verifies who they are and hands back a confirmed email address,
`ExternalAuthController` looks that email up against AUA's membership webservice, and the
result drives member-only gating exactly where `MembersOnly` used to check the simulated
cookie.

**One thing this doesn't solve yet:** the actual by-email membership lookup. This project's
only confirmed-working AUA API so far (`GetAccountInfo`, used by `AccountLookupController`) is
keyed by `customerId`, not email — there's no confirmed email-based endpoint. I built
`AuaMemberLookupService` as a stub with a placeholder URL and response shape so everything
else (login, account creation, claims, gating) is real and working today; you'll need to swap
in the real endpoint once you have it. See the TODO comment at the top of that file.

---

## 1. New/changed files

All delivered in full — paste these into your project at the paths shown.

| File | Action |
|---|---|
| `Helpers/MemberAuthHelper.cs` | New |
| `Services/AuaMemberLookupService.cs` | New (has a TODO — see above) |
| `Controllers/ExternalAuthController.cs` | New |
| `Views/Shared/_ExternalLoginButtons.cshtml` | New |
| `Views/Shared/_SiteFooter.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/StandardContentPageDefault.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/LongFormDocumentPageDefault.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/ClinicalGuidanceDocumentAtomicPilot.cshtml` | Replace with the updated version |
| `Program.cs` | Apply the diff below |
| `Controllers/SimulatedAuthController.cs` | **Delete** |
| `Helpers/SimulatedAuthHelper.cs` | **Delete** |

---

## 2. NuGet packages

```powershell
cd C:\Users\pkerley\Documents\Kentico
dotnet add package Microsoft.AspNetCore.Authentication.Google
dotnet add package Microsoft.AspNetCore.Authentication.Facebook
```

---

## 3. `Program.cs` diff

Four separate changes, in order:

**a. Usings** — add near the top, alongside the existing `Microsoft.AspNetCore.*` usings:

```csharp
using AUA.Services;
using Microsoft.AspNetCore.Authentication.Facebook;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.Extensions.Configuration;
```

**b. Service registration** — where `ConfigureMembershipServices(builder.Services);` is
currently called, change to:

```csharp
ConfigureMembershipServices(builder.Services, builder.Configuration);

// Backs ExternalAuthController's post-login membership check.
builder.Services.AddScoped<IAuaMemberLookupService, AuaMemberLookupService>();
```

**c. `ConfigureMembershipServices` method** — change the signature to accept `IConfiguration`,
and add the Google/Facebook registration right after the existing `.AddSignInManager<...>();`
line, before `services.ConfigureApplicationCookie(...)`:

```csharp
static void ConfigureMembershipServices(IServiceCollection services, IConfiguration configuration)
{
    services.AddIdentity<ApplicationUser, ApplicationRole>(options =>
    {
        // ...unchanged...
    })
        .AddUserStore<ApplicationUserStore<ApplicationUser>>()
        .AddRoleStore<ApplicationRoleStore<ApplicationRole>>()
        .AddUserManager<UserManager<ApplicationUser>>()
        .AddRoleManager<RoleManager<ApplicationRole>>()
        .AddSignInManager<SignInManager<ApplicationUser>>();

    // ADD THIS BLOCK:
    services.AddAuthentication()
        .AddGoogle(options =>
        {
            options.ClientId = configuration["Authentication:Google:ClientId"];
            options.ClientSecret = configuration["Authentication:Google:ClientSecret"];
            options.SignInScheme = IdentityConstants.ExternalScheme;
        })
        .AddFacebook(options =>
        {
            options.AppId = configuration["Authentication:Facebook:AppId"];
            options.AppSecret = configuration["Authentication:Facebook:AppSecret"];
            options.SignInScheme = IdentityConstants.ExternalScheme;
        });

    services.ConfigureApplicationCookie(options =>
    {
        // ...unchanged...
    });
    // ...rest of the method unchanged...
}
```

**d. Route mapping** — replace the `simulated-auth` route with:

```csharp
app.MapControllerRoute(
   name: "external-auth",
   pattern: "external-auth/{action=Login}",
   defaults: new { controller = "ExternalAuth" }
);
```

---

## 4. Google Cloud Console app

1. https://console.cloud.google.com → create or select a project → **APIs & Services** →
   **Credentials** → **Create Credentials** → **OAuth client ID**.
2. Application type: **Web application**.
3. **Authorized redirect URIs** — add both (local dev and wherever this eventually deploys):
   - `https://localhost:<your-https-port>/signin-google`
   - `https://<your-real-domain>/signin-google`

   `/signin-google` is ASP.NET Core's own default callback path for the Google handler — you
   don't set this in code, it's automatic.
4. If prompted, configure the **OAuth consent screen** first (app name, support email) —
   External user type is fine for testing; add yourself as a test user if it's still in
   "Testing" publishing status.
5. Copy the generated **Client ID** and **Client Secret**.

---

## 5. Facebook Developer app

1. https://developers.facebook.com/apps → **Create App** → choose a use case that includes
   "Facebook Login" (e.g. "Authenticate and request data from users with Facebook Login").
2. Add the **Facebook Login** product → **Settings** → **Valid OAuth Redirect URIs**:
   - `https://localhost:<your-https-port>/signin-facebook`
   - `https://<your-real-domain>/signin-facebook`
3. **Settings → Basic** — copy the **App ID** and **App Secret**.
4. While the app is in **Development** mode, only users added as testers/developers on the app
   can log in with it — switch to **Live** mode (requires app review for some permissions) once
   ready for real visitors.

---

## 6. Secrets

```powershell
cd C:\Users\pkerley\Documents\Kentico
dotnet user-secrets set "Authentication:Google:ClientId" "<your Google client ID>"
dotnet user-secrets set "Authentication:Google:ClientSecret" "<your Google client secret>"
dotnet user-secrets set "Authentication:Facebook:AppId" "<your Facebook app ID>"
dotnet user-secrets set "Authentication:Facebook:AppSecret" "<your Facebook app secret>"
```

(`AuaApi:Username` / `AuaApi:Password` should already be set from the Account Lookup feature —
`AuaMemberLookupService` reuses those same two keys.)

---

## 7. How gating changed

Every place that used to check `SimulatedAuthHelper.IsSimulatedMember(Context)` now checks
`MemberAuthHelper.IsAuaMember(Context)` — these are **not** the same thing. `IsAuaMember` is
only true once `ExternalAuthController.Callback` has both (a) verified a real email via
Google/Facebook, **and** (b) `AuaMemberLookupService` confirmed that email is an active AUA
member. Being signed in with a valid Google account and NOT being an AUA member is a real,
expected state — the member-gate blocks in all 3 page templates now show a distinct message
for that case ("Signed in as x@example.com, but we don't have an active AUA membership on file
for this address") instead of just re-showing the sign-in buttons.

`MemberAuthHelper.IsAuthenticated(Context)` answers "is anyone signed in at all," separate from
membership — use that if you need it (e.g. showing "Signed in as ..." in the footer regardless
of membership status).

---

## 8. Verify

- [ ] `dotnet build` succeeds after pasting in all the files above and deleting the 2 simulated
      files.
- [ ] Footer shows "Sign in with Google" / "Sign in with Facebook" when signed out.
- [ ] Clicking either redirects to the real provider's login page, then back to the site,
      signed in, with the correct email shown in the footer.
- [ ] A page with `MembersOnly` set shows the gated preview + sign-in buttons when signed out.
- [ ] After signing in with an email `AuaMemberLookupService` doesn't recognize as a member
      (expected until the real endpoint is wired in — it currently always returns `null` /
      not-a-member unless you temporarily hardcode a test response), the gate shows the
      "signed in but no active membership" message instead of the full body.
- [ ] Sign out via the footer link actually clears the session (reload shows signed-out state).
