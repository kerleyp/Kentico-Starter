# Moving all content into the Content Hub (atomic model, all 3 page types)

Extends the atomic content model — proven and already fully live for the 45 Clinical Guidance
pages — to the other 659 pages: `AUA.StandardContentPage` (614) and `AUA.LongFormDocumentPage`
(~45). Same pattern throughout: a new reusable content type holds the real
Title/Headline/MetaDescription/MetaKeywords/Body/NeedsManualContentReview, the page type gets a
new single-item link field pointing at it, and a one-shot migration trigger creates a matching
reusable item for every existing page and points the new field at it.

Taxonomy tag fields (`SiteSection`, `Audience`, `ClinicalDomain`) deliberately **stay on the
page**, not the new reusable items — matching what Clinical Guidance already does (its own
known limitation note says the same). The Topics sidebar on `StandardContentPageDefault.cshtml`
reads those straight off `currentPage` and is unaffected either way. Gating (`AccessLevel`),
hero image, and Related Topics also stay page-level, same as Clinical Guidance.

---

## 1. Admin UI — 2 new reusable content types

**Content Hub → Content Types → New content type** (reusable, not a page type), for each:

### `AUA.StandardContent`

| Field | Data type | Form component |
|---|---|---|
| Title | Text | Text input |
| Headline | Text | Text input |
| MetaDescription | Long text | Text area |
| MetaKeywords | Text | Text input |
| Body | Rich text (HTML) | Rich text editor |
| NeedsManualContentReview | Boolean | Checkbox |

### `AUA.LongFormContent`

Same 6 fields, same types/components.

---

## 2. Admin UI — 2 new fields on the existing page types

**Content Types → `AUA.StandardContentPage` → Fields tab → add:**

- **Field name:** `PageContent`
- **Data type:** Pages and reusable content → **AUA.StandardContent**
- **Form component:** Combined content selector, single item

**Content Types → `AUA.LongFormDocumentPage` → Fields tab → add:**

- **Field name:** `DocumentContent`
- **Data type:** Pages and reusable content → **AUA.LongFormContent**
- **Form component:** Combined content selector, single item

Save both. **Restart `dotnet run`** before codegen — same class-structure caching gotcha as
every other content-type change in this project.

---

## 3. Regenerate code

```powershell
dotnet build
dotnet run --no-build -- --kxp-codegen --type "ReusableContentTypes" --include "AUA.StandardContent"
dotnet run --no-build -- --kxp-codegen --type "ReusableContentTypes" --include "AUA.LongFormContent"
dotnet run --no-build -- --kxp-codegen --type "PageContentTypes" --include "AUA.StandardContentPage"
dotnet run --no-build -- --kxp-codegen --type "PageContentTypes" --include "AUA.LongFormDocumentPage"
dotnet build
```

(Same one-at-a-time, semicolon-not-comma `--include` convention as every other codegen run in
this project.)

---

## 4. New/changed files

| File | Action |
|---|---|
| `PageTemplates/AUA/StandardContentPageDefault.cshtml` | Replace with the updated version |
| `PageTemplates/AUA/LongFormDocumentPageDefault.cshtml` | Replace with the updated version |
| `Program.cs` | Apply the diff below — 2 new trigger blocks |

**`Program.cs` diff:** insert both new trigger blocks immediately after the existing
`MIGRATE_ALL_CLINICAL_GUIDANCE` trigger block (right before the comment `// Twelfth one-shot
trigger: writes Audience + Clinical Domain...`). Both blocks are full copies of
`MIGRATE_ALL_CLINICAL_GUIDANCE`'s proven pattern, retargeted:

- **`MIGRATE_ALL_STANDARD_CONTENT`** — reads `AUA_StandardContentPage`, creates
  `AUA.StandardContent` items, writes back to the new `PageContent` field.
- **`MIGRATE_ALL_LONGFORM_CONTENT`** — reads `AUA_LongFormDocumentPage`, creates
  `AUA.LongFormContent` items, writes back to the new `DocumentContent` field.

Full code for both is in the delivered `Program.cs` — copy the two new blocks from there into
your real project's `Program.cs` at the same location.

Both templates now resolve `Title`/`Headline`/`MetaDescription`/`MetaKeywords`/`Body`/
`NeedsManualContentReview` from the linked item first, falling back to the page's own fields
for anything not yet migrated — so nothing breaks mid-migration, and you can run the trigger,
stop it, and pick up later without any page ever rendering blank.

---

## 5. Run the migrations

```powershell
$env:MIGRATE_ALL_STANDARD_CONTENT="1"
dotnet run
Remove-Item Env:\MIGRATE_ALL_STANDARD_CONTENT
```

```powershell
$env:MIGRATE_ALL_LONGFORM_CONTENT="1"
dotnet run
Remove-Item Env:\MIGRATE_ALL_LONGFORM_CONTENT
```

**Performance note:** `MIGRATE_ALL_STANDARD_CONTENT` processes 614 pages, each 2 API
round-trips (create the Content Hub item, then create/update/publish a draft of the page) —
expect this to run for a while (tens of minutes, not seconds), and it prints a running count
every 25 pages so you can tell it's still working. Both triggers are idempotent — any page
whose link field is already non-empty gets skipped, so if it's interrupted, just run the same
command again and it picks up where it left off.

Run these **any time** — no ordering dependency on anything else in this project (they only
touch each page's own fields, not the folder tree, taxonomies, or menus).

---

## 6. Verify

- [ ] `dotnet build` succeeds after the field/codegen/template changes.
- [ ] `MIGRATE_ALL_STANDARD_CONTENT` finishes with `Failed=0` (some `Skipped` is fine/expected
      on a re-run).
- [ ] `MIGRATE_ALL_LONGFORM_CONTENT` finishes with `Failed=0`.
- [ ] Content Hub now shows 614 `AUA.StandardContent` items and ~45 `AUA.LongFormContent` items,
      alongside the existing `AUA.ClinicalGuidanceContent` items.
- [ ] Spot-check a few pages of each type on the live site — should render identically to
      before (content resolves through the link now, but looks the same).
- [ ] Pick one migrated `AUA.StandardContent` item in Content Hub, edit its Body directly there,
      publish, and confirm the change shows up on the page that links to it — that's the actual
      point of this migration (content genuinely reusable/editable independent of the page).
